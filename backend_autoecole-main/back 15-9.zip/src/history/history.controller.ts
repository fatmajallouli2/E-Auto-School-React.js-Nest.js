import { Controller } from '@nestjs/common';

@Controller('history')
export class HistoryController {}
